<?php
    include('include/dbcon.php');

    // Start the session only if it's not already active
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }

    // For errors
    $error_message = '';


    // Check if the form has been submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Use PREPARED STATEMENTS for security to prevent SQL Injection
        $stmt = mysqli_prepare($con, "SELECT admin_id, first_name, last_name, admin_type, password FROM admin WHERE username = ?");
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
        mysqli_stmt_close($stmt);

        // Verify the user exists and the password is correct
        // Note: This project uses plaintext passwords. In a real-world scenario, you should use password_hash() and password_verify().
        if ($row && $password === $row['password']) {
            // Login successful
            $_SESSION['id'] = $row['admin_id'];

            // Log the user's login activity
            // $log_stmt = mysqli_prepare($con, "INSERT INTO user_log (first_name, middlename, last_name, admin_type, date_log) VALUES (?, ?, ?, ?, NOW())");
            // mysqli_stmt_bind_param($log_stmt, "ssss", $row['first_name'], $row['middlename'], $row['last_name'], $row['admin_type']);
            // mysqli_stmt_execute($log_stmt);
            // mysqli_stmt_close($log_stmt);

            // Redirect to the home page
            
            header("location: home.php");
            exit();
        } else {
            // Login failed
            $error_message = "Invalid username or password. Please try again.";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LMS Login</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="logo">
                    <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
                        <rect width="36" height="36" rx="8" fill="#6366F1"/>
                        <path d="M12 14h12v8H12v-8zm2 2v4h8v-4h-8zm-2-4h12v2H12v-2zm0 12h12v2H12v-2z" fill="white"/>
                    </svg>
                </div>
                <h1>Book Lab Library</h1>
                <p>Library Management System</p>
            </div>
            
            <form class="login-form" id="loginForm" novalidate method="post" action="index.php">
                <div class="form-group">
                    <label for="email">Username</label>
                    <input type="text" id="username" name="username" required >
                    <span class="error-message" id="emailError"></span>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="password-wrapper">
                        <input type="password" id="password" name="password" required autocomplete="current-password">
                        <button type="button" class="password-toggle" id="passwordToggle" aria-label="Toggle password visibility">
                            <svg class="eye-open" width="18" height="18" viewBox="0 0 18 18" fill="none">
                                <path d="M9 3.75C5.25 3.75 2.04 6.24 1.5 9c.54 2.76 3.75 5.25 7.5 5.25s6.96-2.49 7.5-5.25c-.54-2.76-3.75-5.25-7.5-5.25zm0 8.75a3.5 3.5 0 110-7 3.5 3.5 0 010 7zm0-5.5a2 2 0 100 4 2 2 0 000-4z" fill="currentColor"/>
                            </svg>
                            <svg class="eye-closed" width="18" height="18" viewBox="0 0 18 18" fill="none">
                                <path d="M2.25 2.25l13.5 13.5m-4.125-4.125a3 3 0 01-4.243-4.243m4.243 4.243L9 9m2.625 2.625L15 15M9 5.25c1.83 0 3.51.63 4.84 1.68M3.16 6.93A10.97 10.97 0 019 5.25" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                    </div>
                    <span class="error-message" id="passwordError"></span>
                </div>

                <div class="form-options">
                    <label class="checkbox-wrapper">
                        <input type="checkbox" id="remember" name="remember">
                        <span class="checkmark"></span>
                        Remember this device
                    </label>
                    <a href="#" class="forgot-link">Reset password</a>
                </div>

                <button type="submit" class="login-btn" name="login">  
                    <span class="btn-text">Sign In</span>
                    <div class="btn-loader">
                        <div class="spinner"></div>
                    </div>
                </button>
            </form>

            <div class="security-notice">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path d="M8 1L3 3v4.5c0 2.89 2 5.5 5 6 3-0.5 5-3.11 5-6V3l-5-2z" stroke="#10B981" stroke-width="1.5" fill="none"/>
                    <path d="M6 8l1.5 1.5L11 6" stroke="#10B981" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <span>Your connection is secured with 256-bit SSL encryption</span>
            </div>

            <div class="success-message" id="successMessage">
                <div class="success-icon">
                    <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
                        <circle cx="14" cy="14" r="14" fill="#10B981"/>
                        <path d="M9 14l3 3 7-7" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </div>
                <h3>Welcome back</h3>
                <p>Taking you to your dashboard...</p>
            </div>
        </div>
    </div>

    <script src="js/script.js"></script>
</body>
</html>