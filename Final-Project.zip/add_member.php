<?php include('header.php'); ?>

<div class="page-title">
    <div class="title_left">
        <h3>
            <small>Home/ </small>Add Members
        </h3>
    </div>
</div>
<div class="clearfix"></div>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">

            <div class="x_content">
                <!-- content starts here -->

                <form method="post" enctype="multipart/form-data" class="form-horizontal form-label-left">
                    <div class="form-group">
                        <label class="control-label col-md-4" for="first-name">Student Number | ID <span class="required" style="color:red;">*</span>
                        </label>
                        <div class="col-md-4">
                            <input type="number" name="student_id" id="first-name2" required="required" class="form-control col-md-7 col-xs-12">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4" for="first-name">First Name <span class="required" style="color:red;">*</span>
                        </label>
                        <div class="col-md-4">
                            <input type="text" name="first_name" placeholder="Enter First Name" id="first-name2" required="required" class="form-control col-md-7 col-xs-12">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4" for="last-name">Last Name <span class="required" style="color:red;">*</span>
                        </label>
                        <div class="col-md-4">
                            <input type="text" name="last_name" placeholder="Enter Last Name" id="last-name2" required="required" class="form-control col-md-7 col-xs-12">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4" for="last-name">Contact <span class="required" style="color:red;">*</span>
                        </label>
                        <div class="col-md-4">
                            <input type="tel" autocomplete="off" maxlength="10" name="contact" id="last-name2" class="form-control col-md-7 col-xs-12" required="required">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4" for="last-name">Gender <span class="required" style="color:red;">*</span>
                        </label>
                        <div class="col-md-3">
                            <select name="gender" class="select2_single form-control" required="required" tabindex="-1">
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4" for="last-name">Member Type <span class="required" style="color:red;">*</span>
                        </label>
                        <div class="col-md-3">
                            <select name="type" class="select2_single form-control" required="required" tabindex="-1">
                                <option value="Student">Student</option>
                                <option value="Teacher">Teacher</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4" for="last-name">Branch <span class="required" style="color:red;">*</span>
                        </label>
                        <div class="col-md-3">
                            <select name="branch" class="select2_single form-control" required="required" tabindex="-1">
                                <option value="N/A">N/A</option>
                                <option value="CSE">CSE</option>
                                <option value="ME">ME</option>
                                <option value="EC">EC</option>
                                <option value="EN">EN</option>
                                <option value="Civil">Civil</option>
                                <option value="B-pharma">B-pharma</option>
                                <option value="BBA">BBA</option>
                                <option value="MBA">MBA</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-md-4" for="last-name">Address<span class="required" style="color:red;">*</span>
                        </label>
                        <div class="col-md-4">
                            <input type="text" name="address" id="last-name2" class="form-control col-md-7 col-xs-12" required="required">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-md-4">Email <span class="required" style="color:red;">*</span></label>
                        <div class="col-md-4">
                            <input type="email" name="email" class="form-control" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-md-4">Password <span class="required" style="color:red;">*</span></label>
                        <div class="col-md-4">
                            <input type="password" name="password" class="form-control" required>
                        </div>
                    </div>

                    <div class="ln_solid"></div>
                    <div class="form-group">
                        <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                            <a href="member.php"><button type="button" class="btn btn-primary"><i class="fa fa-times-circle-o"></i> Cancel</button></a>
                            <button type="submit" name="submit" class="btn btn-success"><i class="fa fa-plus-square"></i> Submit</button>
                        </div>
                    </div>
                </form>

                <?php
                include('include/dbcon.php');
                if (isset($_POST['submit'])) {
                    $student_id = $_POST['student_id'];
                    $first_name = $_POST['first_name'];
                    $last_name = $_POST['last_name'];
                    $contact = $_POST['contact'];
                    $gender = $_POST['gender'];
                    $type = $_POST['type'];
                    $branch = $_POST['branch'];
                    $address = $_POST['address'];
                    $email      = $_POST['email'];
                    $password   = password_hash($_POST['password'], PASSWORD_DEFAULT);

                    // $regex_num = "/^[6789][0-9]{9}$/";
                    $regex_num = "/^[0-9]{10}$/";


                    $result = mysqli_query($con, "select * from user WHERE user_id='$student_id' OR contact='$contact'") or die(mysqli_error($con));
                    $row = mysqli_num_rows($result);
                    if ($row > 0) {
                        echo "<script>alert('Student Number OR Contact <br> already exist!'); window.location='member.php'</script>";
                    } else if (!preg_match($regex_num, $contact)) {
                        echo "<script>alert('Not a valid contact number'); window.location='member.php'</script>";
                    } else {
                        mysqli_query($con, "insert into user (student_id,first_name, last_name, contact, gender, address, type, branch, user_added,email, password)
						values ('$student_id','$first_name', '$last_name', '$contact', '$gender', '$address', '$type', '$branch', NOW(), '$email', '$password')") or die(mysqli_error($con));
                        echo "<script>alert('User successfully added!'); window.location='member.php'</script>";
                    }
                }
                ?>

                <!-- content ends here -->
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>